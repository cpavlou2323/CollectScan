// sqlite database. uses Node's own built-in sqlite module (Node 22.5+),
// so there's nothing to compile and nothing extra to install for this part
const { DatabaseSync } = require('node:sqlite');
const path = require('path');

const db = new DatabaseSync(path.join(__dirname, 'collectscan.db'));
db.exec('PRAGMA journal_mode = WAL'); // lets reads and writes happen at the same time without locking each other out
db.exec('PRAGMA foreign_keys = ON'); // so deleting a user also deletes their items, see ON DELETE CASCADE below

// users and items are separate tables linked by user_id, rather than one big
// table, so each person's collection stays private and easy to query on its own.
// images are stored as a JSON string (an array of base64 photos) since sqlite
// has no native array type, and a collectable can have more than one photo
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    display_name TEXT NOT NULL DEFAULT 'Collector',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS items (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT 'Other',
    series TEXT NOT NULL DEFAULT '',
    year TEXT NOT NULL DEFAULT '',
    condition TEXT NOT NULL DEFAULT '',
    print_number TEXT NOT NULL DEFAULT '',
    autograph INTEGER NOT NULL DEFAULT 0,
    favourite INTEGER NOT NULL DEFAULT 0,
    notes TEXT NOT NULL DEFAULT '',
    images TEXT NOT NULL DEFAULT '[]',
    date_added TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

// older databases created before the share-link feature existed won't have
// this column yet, so add it if it's missing, and ignore the error if it's already there
try {
  db.exec('ALTER TABLE users ADD COLUMN share_token TEXT');
} catch (err) {
  // column already exists, nothing to do
}

module.exports = db;
