// CollectScan backend. handles accounts, item storage, and the AI identify proxy
require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const itemRoutes = require('./routes/items');
const identifyRoutes = require('./routes/identify');
const meRoutes = require('./routes/me');
const publicRoutes = require('./routes/public');
const { requireAuth } = require('./middleware/auth');

const app = express();
app.use(cors());
app.use(express.json({ limit: '15mb' })); // photos come through as base64, need a bit of headroom

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.use('/api/auth', authRoutes);
// everything below needs a valid login token, requireAuth checks that before the route ever runs
app.use('/api/items', requireAuth, itemRoutes);
app.use('/api/identify', requireAuth, identifyRoutes);
app.use('/api/me', requireAuth, meRoutes);
app.use('/api/public', publicRoutes); // no requireAuth, since that is the whole point of a share link

// picks up the port Cloudflare/hosting sets, falls back to 3001 for running it locally
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`CollectScan backend running on port ${PORT}`));
