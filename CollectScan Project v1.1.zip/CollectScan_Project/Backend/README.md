# CollectScan backend

A small Node/Express server that gives CollectScan real accounts, a proper
database, and safe AI photo identification — the three things a plain static
site can't do on its own.

## What it does

- **Accounts** — signup/login with hashed passwords (bcrypt) and login tokens (JWT)
- **Database** — SQLite (one file, `collectscan.db`, created automatically — using Node's own built-in SQLite support, so there's nothing to compile and no separate database server to install)
- **Items** — full save/edit/delete, scoped to each account, so nobody can see or touch anyone else's collection
- **AI identify** — takes a photo, asks Google's Gemini (free tier, no credit card) to guess what it is, running server-side so the API key never has to sit in the browser

## Running it locally

Needs Node 22.5 or newer (for its built-in SQLite support) — check with
`node -v`. If you're on an older version, [nodejs.org](https://nodejs.org)
has current installers for Mac/Windows; the Raspberry Pi guide below covers
Linux.

```
npm install
cp .env.example .env
```

Open `.env` and fill in:
- `JWT_SECRET` — any long random string (used to sign login tokens — mash the keyboard, it just needs to be unpredictable)
- `GEMINI_API_KEY` — a free Google Gemini API key, from aistudio.google.com/apikey (no credit card needed). The auto-identify feature won't work without one, but everything else (accounts, saving items) works fine either way.

Then:

```
node server.js
```

You should see `CollectScan backend running on port 3001`. Leave this running in its own terminal window while you use the site.

## Connecting the frontend to it

The frontend's `app.js` has this near the top:

```js
const API_BASE = 'http://localhost:3001/api';
```

That's already correct for testing on your own computer. Once you deploy this backend somewhere (see below), change that line to your deployed URL, e.g. `https://collectscan-backend.onrender.com/api`.

## Deploying it somewhere real

GitHub Pages can only host static files, not a server like this one, so the
backend needs to live somewhere else.

**If you have a Raspberry Pi**, see `RASPBERRY_PI.md` in this folder — it
walks through running the backend there permanently, for free, reachable
from the internet, with no cloud costs and no credit card. This is the
recommended path if a Pi is available to you.

If you'd rather use a cloud host instead (Render, Railway, Fly.io, etc.),
the general steps are the same everywhere:

1. Push this `Backend` folder to a repo the host can pull from.
2. Create a new web service pointed at it, with the start command `node server.js`.
3. Add `JWT_SECRET` and `GEMINI_API_KEY` as environment variables in the host's dashboard — never commit your real `.env` file to git.
4. Once deployed, copy the URL it gives you and update `API_BASE` in the frontend's `app.js` to match, then redeploy the frontend to GitHub Pages.

Free tiers on cloud hosts often "sleep" after a period of no traffic, so the
first request after a while can take 10-20 seconds to wake back up — one
more reason the Pi option avoids a rough edge cloud free tiers have.

## Project structure

```
server.js           — entry point, wires up all the routes
db.js                — SQLite setup (users + items tables)
middleware/auth.js   — checks the login token on protected routes
routes/auth.js       — POST /api/auth/signup, POST /api/auth/login
routes/me.js         — GET/PUT /api/me (your own account's display name)
routes/items.js      — GET/POST/PUT/DELETE /api/items
routes/identify.js   — POST /api/identify (the AI photo lookup)
RASPBERRY_PI.md      — step-by-step guide to hosting this for free on a Pi
deploy/              — the two systemd service files that guide installs
```

## A note on this being a school project

This is a genuinely working backend, not a mock — passwords are actually
hashed, tokens actually expire (30 days), and one account genuinely cannot
read another account's items (there's an automated test that checks this
specifically). It's intentionally simple though: SQLite instead of a bigger
database engine, no email verification or password reset flow, no rate
limiting. Good honest next steps if you want to keep building on it.
