// proxies a photo to Google's Gemini API so the API key never has to reach the
// browser. uses Gemini specifically because its free tier includes image
// understanding (analysing a photo), and needs no credit card
const express = require('express');
const router = express.Router();

const CATEGORIES = ['Cards', 'Cars', 'Lego', 'Figurines', 'Other'];
const MODEL = 'gemini-3.6-flash';

// tells Gemini exactly which fields to return and in what shape, so the
// response can be parsed straight into an item without the frontend having
// to guess at field names or handle free-form text
const PROMPT =
  'You are helping catalogue a physical collectable (trading card, ' +
  'Hot Wheels/diecast car, Lego set, figurine, or similar) from a photo ' +
  'for a personal collection-tracking app called CollectScan. Study the ' +
  'image and reply with ONLY raw JSON (no markdown fences, no commentary) ' +
  'using exactly these keys: ' +
  '{"name": string, "category": one of "Cards"|"Cars"|"Lego"|"Figurines"|"Other", ' +
  '"series": string, "year": string, "condition": string, "printNumber": string, ' +
  '"autograph": boolean}. ' +
  'Leave a field as an empty string (or false for autograph) if you are not ' +
  'reasonably confident. Do not invent specific facts you cannot see.';

router.post('/', async (req, res) => {
  const started = Date.now();
  console.log('[identify] request received');

  const { image, mediaType } = req.body || {};
  if (!image) {
    console.log('[identify] rejected, no image in request body');
    return res.status(400).json({ error: 'no image provided' });
  }
  if (!process.env.GEMINI_API_KEY) {
    console.log('[identify] rejected, no GEMINI_API_KEY set on the server');
    return res.status(500).json({ error: 'server has no GEMINI_API_KEY set, see backend README' });
  }

  console.log(`[identify] photo size: ${Math.round(image.length / 1024)}KB base64, calling Gemini...`);

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': process.env.GEMINI_API_KEY,
        },
        body: JSON.stringify({
          contents: [{
            parts: [
              { inline_data: { mime_type: mediaType || 'image/jpeg', data: image } },
              { text: PROMPT },
            ],
          }],
        }),
      }
    );

    console.log(`[identify] Gemini responded with status ${response.status} after ${Date.now() - started}ms`);

    if (!response.ok) {
      // logging the full error body, not just the status, is what actually
      // revealed the Gemini model deprecation during development, a status
      // code alone wouldn't have said which model to switch to
      const detail = await response.text();
      console.log('[identify] Gemini error body:', detail.slice(0, 500));
      return res.status(502).json({ error: 'the AI service returned an error', detail });
    }

    const data = await response.json();
    const parts = (data.candidates || [])[0]?.content?.parts || [];
    const textPart = parts.find((p) => typeof p.text === 'string');
    if (!textPart) {
      console.log('[identify] no text part in Gemini response:', JSON.stringify(data).slice(0, 500));
      return res.status(502).json({ error: 'no text in the AI response' });
    }

    // Gemini sometimes wraps its JSON in ```json fences even when told not to, strip them before parsing
    const clean = textPart.text.replace(/```json|```/g, '').trim();
    let parsed;
    try {
      parsed = JSON.parse(clean);
    } catch (e) {
      console.log('[identify] could not parse Gemini text as JSON:', clean.slice(0, 500));
      return res.status(502).json({ error: "couldn't parse the AI's response as JSON" });
    }
    // Gemini can occasionally return a category that isn't one of ours, fall back rather than store a bad value
    if (!CATEGORIES.includes(parsed.category)) parsed.category = 'Other';
    console.log(`[identify] success in ${Date.now() - started}ms:`, parsed.name);
    res.json(parsed);
  } catch (err) {
    console.log(`[identify] fetch to Gemini failed after ${Date.now() - started}ms:`, err.message);
    res.status(502).json({ error: 'could not reach the AI service', detail: String(err) });
  }
});

module.exports = router;
