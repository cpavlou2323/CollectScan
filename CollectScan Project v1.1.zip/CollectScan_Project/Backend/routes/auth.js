// signup + login
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');

const router = express.Router();

// builds the login token every successful signup/login returns, expires
// after 30 days so a user isn't forced to log in again constantly, but also
// isn't logged in forever if the token ever leaks
function makeToken(user) {
  return jwt.sign({ sub: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '30d' });
}

router.post('/signup', async (req, res) => {
  const { email, password, displayName } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email and password are required' });
  if (password.length < 8) return res.status(400).json({ error: 'password needs to be at least 8 characters' });

  const cleanEmail = email.toLowerCase().trim();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(cleanEmail);
  if (existing) return res.status(409).json({ error: 'an account with that email already exists' });

  // bcrypt.hash never stores the real password, only a salted hash, so even
  // a full copy of the database wouldn't reveal what anyone actually typed
  const hash = await bcrypt.hash(password, 10);
  const name = (displayName || 'Collector').trim() || 'Collector';
  const info = db.prepare('INSERT INTO users (email, password_hash, display_name) VALUES (?, ?, ?)')
    .run(cleanEmail, hash, name);

  const token = makeToken({ id: info.lastInsertRowid, email: cleanEmail });
  res.json({ token, displayName: name });
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email and password are required' });

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim());
  if (!user) return res.status(401).json({ error: 'incorrect email or password' });

  // same generic error whether the email doesn't exist or the password is wrong,
  // so a stranger can't use the error message to work out which emails are registered
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'incorrect email or password' });

  const token = makeToken(user);
  res.json({ token, displayName: user.display_name });
});

module.exports = router;
