// public, read-only view of a collection via a share link. no login required,
// and only ever returns what a stranger visiting the link should be able to see
// (no email, no account id, no editing)
const express = require('express');
const db = require('../db');
const router = express.Router();

router.get('/:token', (req, res) => {
  const user = db.prepare('SELECT id, display_name FROM users WHERE share_token = ?').get(req.params.token);
  if (!user) return res.status(404).json({ error: 'that share link is not valid' });

  const rows = db.prepare('SELECT * FROM items WHERE user_id = ? ORDER BY date_added DESC').all(user.id);
  const items = rows.map((row) => ({
    id: row.id,
    name: row.name,
    category: row.category,
    series: row.series,
    year: row.year,
    condition: row.condition,
    printNumber: row.print_number,
    autograph: Boolean(row.autograph),
    favourite: Boolean(row.favourite),
    images: JSON.parse(row.images || '[]'),
  }));

  res.json({ displayName: user.display_name, items });
});

module.exports = router;
