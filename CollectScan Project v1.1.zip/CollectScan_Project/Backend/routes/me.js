// the logged-in user's own profile
const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const router = express.Router();

function makeShareToken() {
  return crypto.randomBytes(9).toString('base64url'); // short, url-safe, ~12 chars
}

// fetch the logged-in user's own email and display name, for the profile menu
router.get('/', (req, res) => {
  const user = db.prepare('SELECT id, email, display_name FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'user not found' });
  res.json({ email: user.email, displayName: user.display_name });
});

// change the display name shown in the greeting and profile menu
router.put('/', (req, res) => {
  const name = ((req.body || {}).displayName || '').trim() || 'Collector';
  db.prepare('UPDATE users SET display_name = ? WHERE id = ?').run(name, req.user.id);
  res.json({ displayName: name });
});

// returns the user's existing share link token, creating one on first request
router.get('/share', (req, res) => {
  const user = db.prepare('SELECT share_token FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'user not found' });

  let token = user.share_token;
  if (!token) {
    token = makeShareToken();
    db.prepare('UPDATE users SET share_token = ? WHERE id = ?').run(token, req.user.id);
  }
  res.json({ token });
});

// swaps in a new token, which quietly invalidates any link shared before now
router.post('/share/reset', (req, res) => {
  const token = makeShareToken();
  db.prepare('UPDATE users SET share_token = ? WHERE id = ?').run(token, req.user.id);
  res.json({ token });
});

module.exports = router;
