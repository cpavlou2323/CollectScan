// items CRUD, always scoped to req.user.id so one account never sees another's stuff
const express = require('express');
const db = require('../db');

const router = express.Router();

// converts a raw database row into the shape the frontend expects (camelCase
// fields, images parsed back from a JSON string into a real array, booleans
// instead of sqlite's 0/1), used by every route below so the shape only lives in one place
function rowToItem(row) {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    series: row.series,
    year: row.year,
    condition: row.condition,
    printNumber: row.print_number,
    autograph: Boolean(row.autograph),
    favourite: Boolean(row.favourite),
    notes: row.notes,
    images: JSON.parse(row.images || '[]'),
    dateAdded: row.date_added,
  };
}

// list every item belonging to the logged-in user, newest first
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT * FROM items WHERE user_id = ? ORDER BY date_added DESC').all(req.user.id);
  res.json(rows.map(rowToItem));
});

// create a new item, generates its own id/date if the frontend didn't send one
router.post('/', (req, res) => {
  const b = req.body || {};
  const id = b.id || ('item_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8));
  const dateAdded = b.dateAdded || new Date().toISOString();

  db.prepare(`
    INSERT INTO items (id, user_id, name, category, series, year, condition, print_number, autograph, favourite, notes, images, date_added)
    VALUES (@id, @userId, @name, @category, @series, @year, @condition, @printNumber, @autograph, @favourite, @notes, @images, @dateAdded)
  `).run({
    id, userId: req.user.id,
    name: b.name || '', category: b.category || 'Other', series: b.series || '', year: b.year || '',
    condition: b.condition || '', printNumber: b.printNumber || '',
    autograph: b.autograph ? 1 : 0, favourite: b.favourite ? 1 : 0,
    notes: b.notes || '', images: JSON.stringify(b.images || []), dateAdded,
  });

  const row = db.prepare('SELECT * FROM items WHERE id = ? AND user_id = ?').get(id, req.user.id);
  res.status(201).json(rowToItem(row));
});

// update an item, and 404 if it doesn't exist or belongs to someone else,
// rather than silently doing nothing, so the frontend knows the save actually failed
router.put('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM items WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!existing) return res.status(404).json({ error: 'item not found' });

  const b = req.body || {};
  db.prepare(`
    UPDATE items SET name=@name, category=@category, series=@series, year=@year, condition=@condition,
      print_number=@printNumber, autograph=@autograph, favourite=@favourite, notes=@notes, images=@images
    WHERE id=@id AND user_id=@userId
  `).run({
    id: req.params.id, userId: req.user.id,
    // ?? keeps whatever was already saved for any field the request didn't include,
    // so a partial update never wipes out fields the caller wasn't trying to change
    name: b.name ?? existing.name, category: b.category ?? existing.category,
    series: b.series ?? existing.series, year: b.year ?? existing.year,
    condition: b.condition ?? existing.condition, printNumber: b.printNumber ?? existing.print_number,
    autograph: b.autograph !== undefined ? (b.autograph ? 1 : 0) : existing.autograph,
    favourite: b.favourite !== undefined ? (b.favourite ? 1 : 0) : existing.favourite,
    notes: b.notes ?? existing.notes,
    images: b.images ? JSON.stringify(b.images) : existing.images,
  });

  const row = db.prepare('SELECT * FROM items WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  res.json(rowToItem(row));
});

// the WHERE clause includes user_id, so this can never delete an item belonging
// to a different account even if someone guessed another user's item id
router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM items WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.status(204).end();
});

module.exports = router;
