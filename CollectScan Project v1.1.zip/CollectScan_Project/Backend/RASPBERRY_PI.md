# Hosting the backend on a Raspberry Pi (completely free)

This gets the backend running on your Pi, kept alive automatically even
after a reboot, and reachable from the internet — without paying for
anything, without a credit card anywhere, and without touching your
router's port-forwarding settings.

The trick that makes the "reachable from the internet, no router config"
part possible is **Cloudflare Tunnel**: a free program that makes an
outbound-only connection from your Pi to Cloudflare, so nothing needs to be
opened up on your home network. It also gives you HTTPS automatically,
which matters — your GitHub Pages site is HTTPS, and browsers block an
HTTPS page from calling a plain HTTP address, so this isn't optional.

The one trade-off with the free version: the public web address it gives
you is a random one (like `https://some-random-words.trycloudflare.com`)
and it changes if the tunnel ever restarts. That's fine for a school
project — you just note the current address and update one line in
`app.js` if it changes. There's a note at the end about upgrading to a
permanent address later if you want to.

## 1. Get Node.js 22+ on the Pi

Raspberry Pi OS's own package list usually has an old version of Node,
too old for this project (it needs 22.5 or newer). Install a current one
instead:

```
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node -v
```

That last command should print something like `v22.x.x`. If it doesn't,
stop here and sort that out before continuing — nothing else will work
otherwise.

## 2. Get the project onto the Pi

Easiest way is git, same as you're already using for GitHub:

```
git clone https://github.com/<your-username>/<your-repo>.git
cd <your-repo>/Backend
npm install
```

`npm install` should finish in a few seconds with no compiler errors —
this project deliberately avoids anything that needs to be compiled, which
matters on a Pi.

## 3. Set up your .env file

```
cp .env.example .env
nano .env
```

Fill in a `JWT_SECRET` (any long random string — mash the keyboard) and
your `GEMINI_API_KEY` (a free key from aistudio.google.com/apikey, no
credit card needed). Save with `Ctrl+O`, `Enter`, then exit with
`Ctrl+X`.

## 4. Test it runs

```
node server.js
```

You should see `CollectScan backend running on port 3001`. In another
terminal (or from another device on the same network), check:

```
curl http://localhost:3001/api/health
```

You should get back `{"ok":true}`. Once that works, `Ctrl+C` to stop it —
the next step makes it run automatically and permanently instead.

## 5. Make it run automatically (systemd)

This is what keeps it running after you close the terminal, and brings it
back up automatically if the Pi reboots or the process crashes.

Copy the provided service file into place, editing the `User=` and
`WorkingDirectory=` lines first if your username or folder path is
different from `pi` / `/home/pi/...`:

```
sudo cp deploy/collectscan-backend.service /etc/systemd/system/
sudo nano /etc/systemd/system/collectscan-backend.service
```

Then enable and start it:

```
sudo systemctl daemon-reload
sudo systemctl enable collectscan-backend
sudo systemctl start collectscan-backend
sudo systemctl status collectscan-backend
```

The status command should show `active (running)` in green. Check the health endpoint again to confirm:

```
curl http://localhost:3001/api/health
```

## 6. Install cloudflared

```
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64.deb
sudo dpkg -i cloudflared-linux-arm64.deb
cloudflared -v
```

(If your Pi is an older 32-bit model, use `cloudflared-linux-arm` instead
of `cloudflared-linux-arm64` in that URL. Run `uname -m` if you're not
sure — `aarch64` means 64-bit, `armv7l` means 32-bit.)

Confirm where it installed to, since the next step's service file needs
the exact path:

```
which cloudflared
```

## 7. Make the tunnel run automatically too

Edit `deploy/collectscan-tunnel.service` if `which cloudflared` gave a
different path than `/usr/bin/cloudflared`, then:

```
sudo cp deploy/collectscan-tunnel.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable collectscan-tunnel
sudo systemctl start collectscan-tunnel
```

## 8. Find your public URL

```
sudo journalctl -u collectscan-tunnel -n 50 --no-pager | grep trycloudflare
```

Look for a line containing a URL like
`https://some-random-words.trycloudflare.com`. That's your backend's
public address. Test it from any device (even off your home network, like
your phone on mobile data):

```
curl https://some-random-words.trycloudflare.com/api/health
```

## 9. Point the frontend at it

In `Website/app.js`, find this line near the top:

```js
const API_BASE = 'http://localhost:3001/api';
```

Change it to your tunnel URL, with `/api` on the end:

```js
const API_BASE = 'https://some-random-words.trycloudflare.com/api';
```

Commit and push — GitHub Pages will pick up the change and your live site
will now be talking to your Pi.

## If the address ever changes

It'll only change if the tunnel service restarts (a Pi reboot, a crash, or
you manually restarting it). If that happens, just repeat step 8 to get
the new address and update the one line in `app.js` again.

To check it's still the same address after a while:

```
sudo systemctl status collectscan-tunnel
sudo journalctl -u collectscan-tunnel -n 50 --no-pager | grep trycloudflare
```

## Want a permanent address instead?

If you'd rather not have to update `app.js` every time the tunnel
restarts, Cloudflare supports "named" tunnels with a fixed address you
choose yourself — but it requires a free Cloudflare account and a domain
name added to it. If you don't already own a domain, free options for a
subdomain include [is-a.dev](https://www.is-a.dev/) (aimed at exactly this
kind of student/hobby project). This is a bigger one-time setup, covered
in Cloudflare's own guide at
[developers.cloudflare.com/cloudflare-one/connections/connect-networks](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/)
— worth doing once things are working, not something you need before you
can get started.
