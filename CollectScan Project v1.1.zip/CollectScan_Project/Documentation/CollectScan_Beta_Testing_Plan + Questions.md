CollectScan - Beta Testing Plan

Christos Pavlou

Unit 4 Outcome 1, Criterion 9





PURPOSE OF THIS TESTING



Alpha testing already confirmed CollectScan's individual functions work correctly in isolation (see the Testing Report). Beta testing checks something alpha testing cannot, whether real potential users, not me (the developer), can actually use the app successfully, find it clear, and get value from its core purpose, avoiding duplicate purchases of items they already own.





WHAT WILL BE TESTED



Functional requirements

\- Creating an account and logging in

\- Adding an item manually, including triggering the duplicate warning

\- Scanning a photo and using Auto-Identify to pre-fill item details

\- Editing and deleting an existing item

\- Searching, sorting and filtering the collection

\- Viewing the Stats page

\- Generating and opening a shareable collection link



Non-functional requirements

\- How long the app takes to load and respond on a phone over normal home wifi

\- Whether the layout works properly on the tester's own device (phone, tablet, or desktop) without anything cut off or overlapping

\- Whether the app remains usable if a photo upload is slow or the AI identify step takes a few seconds



Relevant characteristics of user experience

\- Whether the duplicate warning is actually noticed by a first-time user, not just technically present

\- Whether it's obvious that Auto-Identify is an AI feature that can make mistakes and should be checked

\- Whether someone with no prior explanation can work out how to add their first item unassisted





SELECTED TESTERS AND WHY



Five testers were chosen deliberately to cover both the app's actual target user and people seeing it for the first time with no context, since both perspectives matter for a genuine usability read:



\- Brother: the actual real world client, an active Hot Wheels and Pokémon collector who has previously bought duplicates by accident. His reaction is the single most relevant test of whether CollectScan solves the actual problem it was built for.

\- Collector Friend: also an active collector, gives a second experienced collector perspective different from a first-time user.

\- Classmate Art, Classmate Daniel, Classmate Noah: familiar with apps generally but have never seen CollectScan before, giving genuine first use reactions without any prior explanation biasing the result.





HOW RESULTS WILL BE COLLECTED



Three separate data collection methods are used, so results don't rely on a single potentially biased source:

1\. Direct observation, watching each tester attempt the core tasks live, without prompting or helping, and noting where they hesitate, misclick, or ask a question.

2\. A short written questionnaire, completed immediately after testing.

3\. A brief follow up interview, asking open ended questions about anything that felt confusing.



Results from all three methods are recorded using the Usability Testing document (Test Number, Transaction, Resources, Result Code, plus a written review and corrective action), which is the instrument actually used to conduct and document this testing.





TESTING PROCEDURE



Each tester is given the live CollectScan link with no prior explanation and asked to complete a fixed list of tasks in order (sign up, add an item, scan a photo, edit an item, check the stats page), observed throughout, then given the questionnaire and a short interview immediately afterward while the experience is still fresh.





QUESTIONNAIRE AND INTERVIEW, PER TESTER



The same set of questions is used for every tester so results can be fairly compared. Answers are written down live during each session.





BROTHER

Questionnaire (bold one for each):

1\. How easy was it to sign up and log in?          **Very easy** / Easy / Okay / Hard / Very hard

2\. How easy was it to add an item manually?          Very easy / Easy / **Okay** / Hard / Very hard

3\. Did you notice the duplicate warning when adding an item you already had?          **Yes** / No

4\. How trustworthy did the Auto-Identify (AI) results feel?          Very / **Somewhat** / Not very / Didn't try it

5\. How would you rate the overall look and feel of the app? (1 to 5)          5

6\. Would you actually use this app to track your own collection?          **Yes** / No / Maybe



Follow up interview (write answers below each question):

1\. Was there any point where you weren't sure what to do next? if so what was it?

No



2\. Was anything confusing or unclear?

No



3\. What was your favourite feature, and why?

The Ai Scan, super easy to use



4\. If you could change one thing about the app, what would it be?

Collection shared page make it more detailed



5\. Did you trust the AI to correctly identify your item? Why or why not?

Yes, because there is lots of data on Pokémon and hot wheels





FRIEND

Questionnaire (bold one for each):

1\. How easy was it to sign up and log in?          **Very easy** / Easy / Okay / Hard / Very hard

2\. How easy was it to add an item manually?          Very easy / **Easy** / Okay / Hard / Very hard

3\. Did you notice the duplicate warning when adding an item you already had?          **Yes** / No

4\. How trustworthy did the Auto-Identify (AI) results feel?          Very / **Somewhat** / Not very / Didn't try it

5\. How would you rate the overall look and feel of the app? (1 to 5)          3

6\. Would you actually use this app to track your own collection?          **Yes** / No / Maybe



Follow up interview (write answers below each question):

1\. Was there any point where you weren't sure what to do next? if so what was it?

No



2\. Was anything confusing or unclear?

No



3\. What was your favourite feature, and why?

Collection page, it was very detailed.



4\. If you could change one thing about the app, what would it be?

add more colour



5\. Did you trust the AI to correctly identify your item? Why or why not?

somewhat because it has helped me in the past with identifying cards





CLASSMATE: ART 



Questionnaire (bold one for each):

1\. How easy was it to sign up and log in?          Very easy / **Easy** / Okay / Hard / Very hard

2\. How easy was it to add an item manually?          Very easy / Easy / **Okay** / Hard / Very hard

3\. Did you notice the duplicate warning when adding an item you already had?          Yes / **No**

4\. How trustworthy did the Auto-Identify (AI) results feel?          **Very** / Somewhat / Not very / Didn't try it

5\. How would you rate the overall look and feel of the app? (1 to 5)          4

6\. Would you actually use this app to track your own collection?          **Yes** / No / Maybe



Follow up interview (write answers below each question):

1\. Was there any point where you weren't sure what to do next? if so what was it?

No



2\. Was anything confusing or unclear?

No



3\. What was your favourite feature, and why?

The auto scan, makes it very quick to add cards



4\. If you could change one thing about the app, what would it be?

probably nothing



5\. Did you trust the AI to correctly identify your item? Why or why not?

yeah because ai is pretty advanced





CLASSMATE: DANIEL



Questionnaire (bold one for each):

1\. How easy was it to sign up and log in?          Very easy / **Easy** / Okay / Hard / Very hard

2\. How easy was it to add an item manually?          Very easy / Easy / **Okay** / Hard / Very hard

3\. Did you notice the duplicate warning when adding an item you already had?          Yes / **No**

4\. How trustworthy did the Auto-Identify (AI) results feel?          Very / **Somewhat** / Not very / Didn't try it

5\. How would you rate the overall look and feel of the app? (1 to 5)          4

6\. Would you actually use this app to track your own collection?          Yes / No / **Maybe**



Follow up interview (write answers below each question):

1\. Was there any point where you weren't sure what to do next? if so what was it?

No



2\. Was anything confusing or unclear?

Stats Page



3\. What was your favourite feature, and why?

Ai card adding, Very simple



4\. If you could change one thing about the app, what would it be?

More data for each item



5\. Did you trust the AI to correctly identify your item? Why or why not?

not really, it might be to complicated





CLASSMATE: NOAH



Questionnaire (bold one for each):

1\. How easy was it to sign up and log in?          **Very easy** / Easy / Okay / Hard / Very hard

2\. How easy was it to add an item manually?          Very easy / **Easy** / Okay / Hard / Very hard

3\. Did you notice the duplicate warning when adding an item you already had?          Yes / **No**

4\. How trustworthy did the Auto-Identify (AI) results feel?          Very / **Somewhat** / Not very / Didn't try it

5\. How would you rate the overall look and feel of the app? (1 to 5)          4

6\. Would you actually use this app to track your own collection?          Yes / No / **Maybe**



Follow up interview (write answers below each question):

1\. Was there any point where you weren't sure what to do next? if so what was it?

No



2\. Was anything confusing or unclear?

Finding the share collection option



3\. What was your favourite feature, and why?

ai scan, its pretty helpful for quick adding cards without research



4\. If you could change one thing about the app, what would it be?

Favorites wheel



5\. Did you trust the AI to correctly identify your item? Why or why not?

I didn't think it would work but it did



